// These styles apply to every route in the application
import '@/styles/globals.css'
 
export default function App({ Component, pageProps }) {
  return <Component {...pageProps} />
}